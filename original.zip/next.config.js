/** @type {import('next').NextConfig} */
const nextConfig = {
  // Next 16: ESLint config is no longer allowed here
};

module.exports = nextConfig;
